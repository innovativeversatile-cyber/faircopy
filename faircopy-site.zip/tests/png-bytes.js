import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const here = path.dirname(fileURLToPath(import.meta.url));
export const PNG = fs.readFileSync(path.join(here, "fixtures", "letter.png"));
