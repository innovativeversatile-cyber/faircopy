import { test, expect } from "playwright/test";
import { PNG } from "./png-bytes.js";

test.describe("Fair Copy", () => {
  test("first glance is a desk, not a pitch", async ({ page }) => {
    await page.goto("/index.html");
    await expect(page.locator("h1")).toHaveText("Your papers never leave this device.");
    await expect(page.getByRole("button", { name: "Take photo" })).toBeVisible();
    await expect(page.getByRole("button", { name: "Choose photos" })).toBeVisible();
    await expect(page.locator("body")).not.toContainText(/seamless|empower|revolution|cutting-edge|AI-powered/i);
    const title = await page.title();
    expect(title.startsWith("Fair Copy")).toBeTruthy();
  });

  test("privacy page says files are not uploaded", async ({ page }) => {
    await page.goto("/privacy.html");
    await expect(page.locator("h1")).toHaveText("Nothing you photograph is sent to us.");
    await expect(page.locator("body")).toContainText("not uploaded");
  });

  test("a photo becomes a PDF on this device", async ({ page }) => {
    await page.goto("/index.html");
    const downloadPromise = page.waitForEvent("download", { timeout: 30000 });
    await page.locator("#input-files").setInputFiles({
      name: "letter.png",
      mimeType: "image/png",
      buffer: PNG
    });
    await expect(page.getByRole("button", { name: "Make PDF" })).toBeEnabled();
    await page.getByRole("button", { name: "Paper" }).click();
    await page.getByRole("button", { name: "Make PDF" }).click();
    const download = await downloadPromise;
    expect(download.suggestedFilename()).toMatch(/^Fair-Copy-.*\.pdf$/);
    const stream = await download.createReadStream();
    const chunks = [];
    for await (const chunk of stream) chunks.push(chunk);
    const bytes = Buffer.concat(chunks);
    expect(bytes.subarray(0, 4).toString("ascii")).toBe("%PDF");
    expect(bytes.length).toBeGreaterThan(1000);
  });

  test("a fifth page asks you to split or wait for a pass", async ({ page }) => {
    await page.goto("/index.html");
    const files = Array.from({ length: 5 }, (_, i) => ({
      name: `p${i + 1}.png`,
      mimeType: "image/png",
      buffer: PNG
    }));
    await page.locator("#input-files").setInputFiles(files);
    await expect(page.getByRole("dialog", { name: "Four pages on the free copy" })).toBeVisible();
    await expect(page.locator("#page-count")).toContainText("4 of 4");
  });

  test("language and currency can be changed on the page", async ({ page }) => {
    await page.goto("/index.html");
    await expect(page.locator("#pref-lang option")).toHaveCount(7);
    await expect(page.locator("[data-price=day]")).toHaveText(/\$3|USD/);

    await page.selectOption("#pref-lang", "fr");
    await expect(page.locator("h1")).toHaveText("Vos papiers ne quittent pas cet appareil.");
    await expect(page.getByRole("button", { name: "Prendre une photo" })).toBeVisible();
    await expect(page.locator("#pref-lang")).toHaveValue("fr");

    await page.selectOption("#pref-currency", "EUR");
    await expect(page.locator("[data-price=day]")).toContainText("€");
    await expect(page.locator("[data-price=year]")).toContainText("18");

    await page.selectOption("#pref-currency", "KES");
    await expect(page.locator("[data-price=day]")).toContainText("400");

    await page.reload();
    await expect(page.locator("html")).toHaveAttribute("lang", "fr");
    await expect(page.locator("h1")).toHaveText("Vos papiers ne quittent pas cet appareil.");
    await expect(page.locator("#pref-currency")).toHaveValue("KES");
    await expect(page.locator("[data-price=day]")).toContainText("400");

    await page.goto("/privacy.html");
    await expect(page.locator("h1")).toHaveText("Rien de ce que vous photographiez ne nous est envoyé.");
    await expect(page.locator("#pref-lang")).toHaveValue("fr");
  });
});
