import { chromium } from "playwright";
import fs from "fs";
import path from "path";
import { createServer } from "http";
import { fileURLToPath } from "url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const out = "/opt/cursor/artifacts/screenshots";
fs.mkdirSync(out, { recursive: true });
const png = fs.readFileSync(path.join(root, "tests/fixtures/letter.png"));

const mime = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css",
  ".js": "text/javascript",
  ".svg": "image/svg+xml",
  ".png": "image/png"
};
const server = createServer((req, res) => {
  const rel = decodeURIComponent(req.url.split("?")[0]).replace(/^\//, "") || "index.html";
  const file = path.join(root, rel);
  if (!file.startsWith(root) || !fs.existsSync(file)) {
    res.writeHead(404);
    res.end();
    return;
  }
  res.writeHead(200, { "content-type": mime[path.extname(file)] || "application/octet-stream" });
  fs.createReadStream(file).pipe(res);
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const { port } = server.address();
const base = `http://127.0.0.1:${port}`;
const browser = await chromium.launch();

async function shot(name, viewport, fn) {
  const page = await browser.newPage({ viewport });
  await fn(page);
  await page.screenshot({ path: path.join(out, name), fullPage: true });
  await page.close();
}

await shot("faircopy-landing-phone.png", { width: 390, height: 844 }, async (page) => {
  await page.goto(`${base}/index.html`, { waitUntil: "networkidle" });
});

await shot("faircopy-landing-desktop.png", { width: 1280, height: 800 }, async (page) => {
  await page.goto(`${base}/index.html`, { waitUntil: "networkidle" });
});

await shot("faircopy-desk-phone.png", { width: 390, height: 844 }, async (page) => {
  await page.goto(`${base}/index.html`, { waitUntil: "networkidle" });
  await page.locator("#input-files").setInputFiles({
    name: "letter.png",
    mimeType: "image/png",
    buffer: png
  });
  await page.locator("#preview-img").waitFor();
  await page.waitForTimeout(200);
});

await shot("faircopy-ink-desktop.png", { width: 1100, height: 900 }, async (page) => {
  await page.goto(`${base}/index.html`, { waitUntil: "networkidle" });
  await page.locator("#input-files").setInputFiles({
    name: "letter.png",
    mimeType: "image/png",
    buffer: png
  });
  await page.getByRole("button", { name: "Ink" }).click();
  await page.waitForTimeout(250);
});

await shot("faircopy-limit.png", { width: 390, height: 844 }, async (page) => {
  await page.goto(`${base}/index.html`, { waitUntil: "networkidle" });
  const files = Array.from({ length: 5 }, (_, i) => ({
    name: `p${i + 1}.png`,
    mimeType: "image/png",
    buffer: png
  }));
  await page.locator("#input-files").setInputFiles(files);
  await page.getByRole("dialog").waitFor();
});

await shot("faircopy-done.png", { width: 390, height: 844 }, async (page) => {
  await page.goto(`${base}/index.html`, { waitUntil: "networkidle" });
  const [download] = await Promise.all([
    page.waitForEvent("download"),
    (async () => {
      await page.locator("#input-files").setInputFiles({
        name: "letter.png",
        mimeType: "image/png",
        buffer: png
      });
      await page.getByRole("button", { name: "Make PDF" }).click();
    })()
  ]);
  await download.path();
  await page.getByRole("dialog", { name: "The PDF is on this device" }).waitFor();
});

await shot("faircopy-privacy.png", { width: 390, height: 844 }, async (page) => {
  await page.goto(`${base}/privacy.html`, { waitUntil: "networkidle" });
});

await shot("faircopy-how.png", { width: 390, height: 844 }, async (page) => {
  await page.goto(`${base}/index.html#how`, { waitUntil: "networkidle" });
});

await browser.close();
server.close();
console.log("wrote screenshots to", out);
