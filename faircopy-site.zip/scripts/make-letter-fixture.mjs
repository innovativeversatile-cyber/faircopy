import fs from "fs";
import path from "path";
import zlib from "zlib";
import { fileURLToPath } from "url";
import { crc32 } from "zlib";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const width = 900;
const height = 1240;

function chunk(type, data) {
  const typeBuf = Buffer.from(type, "ascii");
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const crcSrc = Buffer.concat([typeBuf, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(crcSrc) >>> 0, 0);
  return Buffer.concat([len, typeBuf, data, crc]);
}

const raw = Buffer.alloc((width * 3 + 1) * height);
const paper = [245, 240, 230];
const ink = [29, 26, 22];
const rule = [207, 195, 171];

for (let y = 0; y < height; y++) {
  const row = y * (width * 3 + 1);
  raw[row] = 0;
  for (let x = 0; x < width; x++) {
    let c = paper;
    if (y >= 180 && y < 1080 && y % 36 < 2 && x >= 90 && x < 810) {
      c = y % 108 === 180 ? ink : rule;
    }
    if (y >= 110 && y < 118 && x >= 90 && x < 420) c = ink;
    const i = row + 1 + x * 3;
    raw[i] = c[0];
    raw[i + 1] = c[1];
    raw[i + 2] = c[2];
  }
}

const ihdr = Buffer.alloc(13);
ihdr.writeUInt32BE(width, 0);
ihdr.writeUInt32BE(height, 4);
ihdr[8] = 8;
ihdr[9] = 2;
const png = Buffer.concat([
  Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
  chunk("IHDR", ihdr),
  chunk("IDAT", zlib.deflateSync(raw)),
  chunk("IEND", Buffer.alloc(0))
]);

const out = path.join(__dirname, "../tests/fixtures/letter.png");
fs.writeFileSync(out, png);
console.log("wrote", out, png.length, "bytes");
